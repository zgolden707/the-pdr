See chat for easy steps. Place your PDR.svg under public/ and deploy to Vercel.
