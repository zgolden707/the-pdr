export const runtime = "nodejs";

import nodemailer from "nodemailer";

export async function POST(req) {
  try {
    const { to, payload } = await req.json();

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: false,
      auth: process.env.SMTP_USER
        ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
        : undefined,
    });

    const html = `<h2>New Join Request</h2><pre>${JSON.stringify(payload, null, 2)}</pre>`;

    await transporter.sendMail({
      from: `"The PDR" <${process.env.SMTP_FROM || "no-reply@thepdr.co"}>`,
      to: to || process.env.WORKSPACE_ALIAS,
      subject: "The PDR - New Join Request",
      html,
    });

    return new Response(JSON.stringify({ ok: true }), { status: 200 });
  } catch (err) {
    console.error("join route error", err);
    return new Response(JSON.stringify({ ok: false }), { status: 500 });
  }
}
